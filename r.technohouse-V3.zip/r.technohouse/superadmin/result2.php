<?php
session_start();
include'dbconnection.php';

if (!(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] != '')) {

header ("Location: index.php");

}
// checking session is valid for not 
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
  } else{

// for deleting user
if(isset($_GET['id']))
{
$adminid=$_GET['id'];
$msg=mysqli_query($con,"delete from users where id='$adminid'");
if($msg)
{
echo "<script>alert('Data deleted');</script>";
}
}
?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link href = "postadmin/css/styles.css" rel = "stylesheet" type = "text/css">

    <title>Admin | Manage Users</title>
    <link rel = "stylesheet" type = "text/css" href = "https://fonts.googleapis.com/css?family=Raleway">
    <link rel = "stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
<style>
  .rightbox{
  text-align:right;
  padding-right:15px;
}
</style>
  </head>

  <body>

  <section id="container" >
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <a href="#" class="logo"><b>Admin Dashboard</b></a>
            <div class="nav notify-row" id="top_menu">
               
                         
                   
                </ul>
            </div>
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="#"><img src="assets/img/logo.jpg" class="img-circle" width="100"></a></p>
              	  <h5 class="centered"><?php echo $_SESSION['login'];?></h5>
              	  	
                  <li class="mt">
                      <a href="change-password.php">
                          <i class="fa fa-file"></i>
                          <span>Change Password</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="status.php" >
                          <i class="fa fa-users"></i>
                          <span>Status</span>
                      </a>
                   
                  </li>

                  <li class="sub-menu">
                      <a href="./request/home.php" >
                          <i class="fa fa-users"></i>
                          <span>Membership</span>
                      </a>
                   
                  </li>

                  <li class="sub-menu">
                      <a href="manage-users.php" >
                          <i class="fa fa-users"></i>
                          <span>Manage Users</span>
                      </a>
                   
                  </li>

                   <li class="sub-menu">
                      <a href="manage-admins.php" >
                          <i class="fa fa-users"></i>
                          <span>Manage Admin</span>
                      </a>
                   
                  </li>

                  <li class="sub-menu">
                      <a href="./postadmin/index.php" >
                          <i class="fa fa-users"></i>
                          <span>Announcement</span>
                      </a>
                   
                  </li>

                   <li class="sub-menu">
                      <a href="./poll/index.php" >
                          <i class="fa fa-users"></i>
                          <span>Polls</span>
                      </a>
                   
                  </li>
              
                 
              </ul>
          </div>
      </aside>
      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i> Manage Users</h3>
				<div class="row">
				
          <div class="rightbox">
          <form action="result2.php" method="get">
          <input type="text" name="search" id="search">
          <button type="submit">Search</button>
          </form>
          </div>
          <br>
	                  
                  <div class="col-md-12">
                      <div class="content-panel">
                          <table class="table table-striped table-advance table-hover">
	                  	  	  <h4><i class="fa fa-angle-right"></i> All User Details </h4>
	                  	  	  <hr>
                              <thead>
                              <tr>
                                  <th>id</th>
                                  <th class="hidden-phone">First Name</th>
                                  <th> Last Name</th>
                                  <th> ID number</th>
                                  <th>Course & Year</th>
                                  <th>Registered Date</th>
                                  <th>Update</th>

                              </tr>
                              </thead>
                              <tbody>
                              <?php 
                              $search = $_GET['search'];
                              $ret=mysqli_query($con,"SELECT * FROM users where fname LIKE '%$search%' || lname LIKE '%$search%' || id_number LIKE '%$search%' || course LIKE '%$search%' || posting_date LIKE '%$search%'");
							  $cnt=1;
							  while($row=mysqli_fetch_array($ret))
							  {?>
                              <tr>
                              <td><?php echo $cnt;?></td>
                                  <td><?php echo $row['fname'];?></td>
                                  <td><?php echo $row['lname'];?></td>
                                  <td><?php echo $row['id_number'];?></td>
                                  <td><?php echo $date2 = $row['course'];?></td> 
                                  <td><?php echo $date1 = $row['posting_date'];?></td>
                                <!--  <td><?php if(strtotime(date("Y/m/d")) < strtotime($date2)) echo "Active"; else { echo "deactive";} ?></td> -->
                                  <td>
                                     
                                     <a href="update-profile.php?uid=<?php echo $row['id'];?>"> 
                                     <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button></a>
                                     <a href="manage-users.php?id=<?php echo $row['id'];?>"> 
                                     <button class="btn btn-danger btn-xs" onClick="return confirm('Do you really want to delete');"><i class="fa fa-trash-o "></i></button></a>
                                  </td>
                              </tr>
                              <?php $cnt=$cnt+1; }?>
                             
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
		</section>
      </section
  ></section>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="assets/js/common-scripts.js"></script>
  <script>
      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
<?php } ?>

