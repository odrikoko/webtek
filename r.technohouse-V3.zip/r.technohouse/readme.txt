database name:
loginsystem
phppoll
phppost

==super admin==
user: superadmin
pass: superadmin123

==admin==
user: admin
pass: admin123

==member==
user: asd@yahoo.com
password: asd