<?php

include_once '../r.posts.php';
$uri = 'poll.php';
header("Location: ".RSITE.$uri);
exit;