==================================================================================
FUNCTIONALITIES : ( na kulang pa sa Poll & Voting System )
==================================================================================

>> FAILING FUNCTIONALITIES =======================================================

** Responsiveness / adaptability
** Can hide the poll
** Even when the page was refresh / reloaded, the contents must still have the same attr as to before the page was reloaded


>> THE QUESTIONABLES =============================================================

[?] No available Service Workers yet
[?] Put a "BACK" button sa may result.php
[?] User can vote multiple times ( dapat ONCE lang )


>> THE ALANGANIN =================================================================

[/] [?] User can choose which poll to vote on
[/] [?] Can VIEW the results before / after voting


>> THE BALAKID SA BUHAY KO =======================================================

[X] Not user - friendly
	-> Pindot here -- pindot there, bes \_('^')_/


>> WORKING FUNCTIONALITIES =======================================================

[/] Can ADD / VIEW / DELETE a poll
	- > Walang "update" a poll. Update lang sa # of votes via database after voting.



==================================================================================
ADDITIONAL : ( FOR LE  )
==================================================================================

<head>
        <meta charset = "utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title> $title </title>

        <link rel = "stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href = "https://fonts.googleapis.com/css?family=Roboto&display=swap" rel = "stylesheet">

        <link href = "../poll/CSS/styles.css" rel = "stylesheet" type = "text/css">
    </head>