<?php

include_once '../r.posts.php';
$rsg->admin_login_redirect();