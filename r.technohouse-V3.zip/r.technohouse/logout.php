<?php
include_once 'r.posts.php';
$rsg->logout();