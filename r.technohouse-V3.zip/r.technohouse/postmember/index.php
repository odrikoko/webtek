<?php

include_once '../r.posts.php';
$uri = 'announcement.php';
header("Location: ".RSITE.$uri);
exit;